package com.example.bewell;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.example.bewell.databinding.ActivityMainBinding;
import com.google.android.material.navigation.NavigationView;

public class MainPage1 extends AppCompatActivity {



    private Button MyProfile;
    private ImageView home;
    private ImageView recipes;
    private  ImageView sport;
    private ImageView profile;
    private Button TryNowBtn;
    private Button Workoutbutton;
    ImageButton myImageButton;
    ImageButton myImageButton2;
    ImageButton myImageButton3;
    ImageButton myImageButton4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main_page1);
        home=findViewById(R.id.imageView15);
        recipes=findViewById(R.id.imageView13);
        sport=findViewById(R.id.imageView14);
        profile=findViewById(R.id.imageView12);
        Workoutbutton = findViewById(R.id.workoutbutton);
        myImageButton = findViewById(R.id.prvaslika);
        myImageButton2 = findViewById(R.id.drugaslika);
        myImageButton3 = findViewById(R.id.trecaslika);
        myImageButton4 = findViewById(R.id.cetvrtaslika);
        TryNowBtn = findViewById(R.id.recipebutton);
        MyProfile = findViewById(R.id.MyProfileBtn);
        MyProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainPage1.this,
                       Account.class));
            }
        });
        TryNowBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainPage1.this, Recipes.class));
            }
        });
        Workoutbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainPage1.this, MyPlan.class));
            }
        });

        myImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainPage1.this, MyPlan.class));
            }
        });

        myImageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainPage1.this, MyPlan.class));
            }
        });
        myImageButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainPage1.this, MyPlan.class));
            }
        });
        myImageButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainPage1.this, MyPlan.class));
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainPage1.this, MainPage1.class));
            }
        });
        recipes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainPage1.this, Recipes.class));
            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainPage1.this, Account.class));
            }
        });
        sport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainPage1.this, MyPlan.class));
            }
        });



    }



}