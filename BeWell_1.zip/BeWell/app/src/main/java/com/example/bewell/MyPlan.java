package com.example.bewell;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MyPlan extends AppCompatActivity {

    private ImageView home;
    private ImageView recipes;
    private  ImageView sport;
    private ImageView profile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_plan);
        home=findViewById(R.id.imageView15);
        recipes=findViewById(R.id.imageView13);
        sport=findViewById(R.id.imageView14);
        profile=findViewById(R.id.imageView12);


        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MyPlan.this, MainPage1.class));
            }
        });
        recipes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MyPlan.this, Recipes.class));
            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MyPlan.this, Account.class));
            }
        });
        sport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MyPlan.this, MyPlan.class));
            }
        });
    }
}