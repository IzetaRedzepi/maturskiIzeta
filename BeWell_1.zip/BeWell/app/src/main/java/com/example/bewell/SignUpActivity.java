package com.example.bewell;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.UUID;

public class SignUpActivity extends AppCompatActivity implements ImageView.OnClickListener{
    private ImageView imageView;
    private FirebaseAuth auth;
    private EditText SignUpEmail,SignUpPass,SignUpUsername;
    private Button signUpButton;
    private ImageView PlusSign;
    private Uri imageUri;
    private ImageView ChangePicture;
    FirebaseDatabase database;
    DatabaseReference reference;
    //povezivanje firebasea
    private FirebaseStorage storage;
    private StorageReference storageReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        imageView=(ImageView) findViewById(R.id.imageView);
        imageView.setOnClickListener(this);

        storage=FirebaseStorage.getInstance();
        storageReference=storage.getReference();
        auth=FirebaseAuth.getInstance();
        SignUpEmail=findViewById(R.id.editTextTextEmailAddress);
        SignUpPass=findViewById(R.id.editTextTextPassword);
        SignUpUsername=findViewById(R.id.editTextUserName);
        signUpButton=findViewById(R.id.signUp);
        PlusSign= findViewById(R.id.imageView2);
        ChangePicture=findViewById(R.id.imageView4);


        PlusSign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                choosePicture();
            }
        });







        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                database=FirebaseDatabase.getInstance();
                reference=database.getReference("Users");
                String user=SignUpEmail.getText().toString().trim();
                String  pass=SignUpPass.getText().toString().trim();
                String  username=SignUpUsername.getText().toString().trim();

                if(user.isEmpty()){
                    SignUpEmail.setError("Please enter your email");
                }
                if(pass.isEmpty()){
                    SignUpPass.setError("Please enter your password");
                }
                if(username.isEmpty()){
                    SignUpUsername.setError("Please enter your username");
                }
                else{
                   auth.createUserWithEmailAndPassword(user,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                       @Override
                       public void onComplete(@NonNull Task<AuthResult> task) {
                           if(task.isSuccessful()){
                               Toast.makeText(SignUpActivity.this, "We are signing you up...",Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(SignUpActivity.this, LogInActivity.class));
                           }
                           else {
                               Toast.makeText(SignUpActivity.this, "SignUp failed"+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                           }
                       }
                   });
                }
            }
        });

    }

    private void choosePicture() {
        Intent intent= new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1 && resultCode==RESULT_OK && data!=null && data.getData()!=null){
            imageUri = data.getData();
            ChangePicture.setImageURI(imageUri);
            uploadPicture();
        }
    }

    private void uploadPicture() {
// Create a reference to "mountains.jpg"
        final String randomKey= UUID.randomUUID().toString();
        StorageReference mountainsRef = storageReference.child("images/" + randomKey);
        mountainsRef.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
               Snackbar.make(findViewById(android.R.id.content), "Image Uploaded.", Snackbar.LENGTH_LONG).show();
            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                   Toast.makeText(getApplicationContext(), "Failed to Upload", Toast.LENGTH_LONG).show();
                    }
                });
// Create a reference to 'images/mountains.jpg'
   //     StorageReference mountainImagesRef = storageReference.child("images/mountains.jpg");

// While the file names are the same, the references point to different files
    //    mountainsRef.getName().equals(mountainImagesRef.getName());    // true
    //    mountainsRef.getPath().equals(mountainImagesRef.getPath());    // false
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.imageView:
                startActivity(new Intent(this, MainActivity.class));
                break;
        }
    }
}