package com.example.bewell;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private Button SignUpButton;
    private Button LogInButton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SignUpButton=(Button) findViewById(R.id.SignUp);
        SignUpButton.setOnClickListener(this);

        LogInButton=(Button) findViewById(R.id.LogIn);
        LogInButton.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.SignUp:
                startActivity(new Intent(this, SignUpActivity.class));
                break;
                case R.id.LogIn:
                startActivity(new Intent(this, LogInActivity.class));
                break;
        }


    }
}