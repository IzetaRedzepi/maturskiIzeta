package com.example.bewell;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LogInActivity extends AppCompatActivity  implements ImageView.OnClickListener{

    private ImageView imageView3;
    private FirebaseAuth auth;
    private EditText LMail, LPass;
    private Button LogInButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        imageView3=(ImageView) findViewById(R.id.imageView3);
        imageView3.setOnClickListener(this);

        auth= FirebaseAuth.getInstance();
        LMail=findViewById(R.id.LogInEmail);
        LPass=findViewById(R.id.LogInPass);
        LogInButton=findViewById(R.id.MyProfileBtn);

        LogInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email=LMail.getText().toString().trim();
                String  pass=LPass.getText().toString().trim();

                if(!email.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    if(!pass.isEmpty()){
                        auth.signInWithEmailAndPassword(email, pass)
                                .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                                    @Override
                                    public void onSuccess(AuthResult authResult) {
                                        Toast.makeText(LogInActivity.this, "LogIn Successful", Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(LogInActivity.this, Welcome.class));
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(LogInActivity.this, "LogIn Failed", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else{
                        LPass.setError("Password cannot be empty");
                    }
                }else if(email.isEmpty()){
                    LMail.setError("Email cannot be empty");
                }
                else{
                    LMail.setError("Please enter valid email");
                }

            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.imageView3:
                startActivity(new Intent(this, MainActivity.class));
                break;
        }
    }
}