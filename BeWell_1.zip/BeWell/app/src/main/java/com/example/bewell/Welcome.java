package com.example.bewell;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;


import java.lang.reflect.Array;
import java.util.ArrayList;


public class Welcome extends AppCompatActivity {
    private ImageSlider imageSlider;
    private Button WelcomeBtn;
    private Button Skip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        imageSlider=findViewById(R.id.imageSlider);
        Skip=findViewById(R.id.SkipBtn);

        ArrayList<SlideModel>slideModels=new ArrayList<>();
        slideModels.add(new SlideModel("https://sarahscoop.com/wp-content/uploads/2022/08/Motivational-Fitness-Quotes-for-Women-Who-Workout.jpg", ScaleTypes.FIT));
        slideModels.add(new SlideModel("https://www.eatwell101.com/wp-content/uploads/2019/04/chicken-bites-and-asparagus-recipe.jpg", ScaleTypes.FIT));
        slideModels.add(new SlideModel("https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1582918394i/51885648._UY2560_SS2560_.jpg", ScaleTypes.FIT));

    imageSlider.setImageList(slideModels, ScaleTypes.FIT);

    WelcomeBtn=findViewById(R.id.signUp3);
    WelcomeBtn.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            startActivity(new Intent(Welcome.this, MainPage1.class));
        }
    });
        Skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(Welcome.this, MainPage1.class));
            }
        });



    }
}